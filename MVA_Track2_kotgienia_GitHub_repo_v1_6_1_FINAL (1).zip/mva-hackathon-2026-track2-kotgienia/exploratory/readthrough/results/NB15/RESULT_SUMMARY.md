# NB15 — produkty odczytu UGA

Wygenerowano WT, produkt skrócony i 19 pełnej długości podstawień pozycji 737.
Panel priorytetowy do doświadczenia: **WT, L737*, L737W, L737C, L737R**.
W/C/R to produkty odczytu UGA obserwowane w innych układach; ich proporcje w BUB1B nie są znane.
W pracy CFTR W1282X obserwowano także leucynę: WT jest więc również możliwym produktem w pewnych kontekstach.
Nie zakładamy wyłączności W/C/R ani obecności leucyny w BUB1B; identyfikacja produktu wymaga pomiaru.
2,6-diaminopuryna wskazuje na W jako produkt mechanistyczny, nie na przywrócenie leucyny.

ESM-2: **COMPLETED**. Jeśli wykonany, porównuje log P(aa|kontekst) względem leucyny w 3 oknach.
Okna to analiza wrażliwości na kontekst, nie niezależne replikacje. Model nie określa aktywności BUBR1,
stabilności białka, prawdopodobieństwa rescue ani klasy ACMG. Nie stosujemy progu PASS na wyniku ESM.

**Werdykt funkcjonalny: INDETERMINATE_REQUIRES_FUNCTION.**
Test przy tej samej ilości białka musi sprawdzić segregację chromosomów, checkpoint i lokalizację.
Do oceny NMD potrzebny jest układ zachowujący odpowiedni kontekst RNA/splicingu;
samo cDNA jest przydatne do badania produktu białkowego, ale nie odtwarza EJC-NMD.
