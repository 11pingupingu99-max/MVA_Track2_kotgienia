# NB16 — translacyjny audyt readthrough

Zintegrowano zgodne, zweryfikowane wyniki NB14 i NB15. ESM: COMPLETED.
Tabela dowodów oddziela wyniki dla BUB1B od wyników uzyskanych dla innych genów.
W zestawie źródeł nie ma bezpośredniego dowodu skuteczności readthrough dla BUB1B-L737*.

**Panel warunkowy, bez rankingu skuteczności:** ataluren i amlexanox do audytu farmakologicznego;
2,6-diaminopuryna jako sonda UGA→W. Żaden związek nie otrzymuje terapeutycznego PASS.
Status regulacyjny zapisano jako datowany stan źródła, a nie automatyczne potwierdzenie dostępności.

Wykonano 432 scenariuszy czterech niewiadomych: ilość RNA × readthrough × stabilność × funkcja.
Wynik odnosi się do **dwóch równie aktywnych alleli WT**; wkład naprawianego pojedynczego allelu ma czynnik 1/2.
Przykład czysto hipotetyczny: RNA=10%, readthrough=10%, stabilność=100%, funkcja=100% daje **0,5%** dawki WT/WT.
Nie estymujemy parametrów z danych innych chorób i nie wyznaczamy procentowego progu terapii.
Wzrost readthrough może wpływać na NMD — czynniki nie muszą być biologicznie niezależne.

Następny informacyjny etap: ustalić dostępność transkryptu i funkcję L737W/C/R przy wyrównanej ilości białka.
Szablon 8 replikacji jest punktem planowania; nie stanowi nowej analizy mocy dla tej gałęzi.
Wyniki ATP, przeżycia lub samej fluorescencji reportera nie wystarczają do wykazania rescue.

**Werdykt: hipoteza nadaje się do testu; skuteczność i użyteczność kliniczna pozostają nieznane.**
