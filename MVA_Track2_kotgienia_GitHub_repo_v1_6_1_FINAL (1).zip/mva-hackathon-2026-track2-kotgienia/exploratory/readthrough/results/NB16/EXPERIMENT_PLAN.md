# Prospektywny plan rozstrzygnięcia L737* / produktów readthrough

To plan dla laboratorium; żaden wiersz szablonu nie jest wykonanym doświadczeniem.

1. **Produkt białkowy:** porównać WT, L737*, L737W, L737C, L737R w układzie komplementacji.
   Wyrównać rzeczywiście zmierzoną ilość białka; identyczna ilość DNA wektora nie jest abundance matching.
   Krzywa 10/30/50/75/100% WT jest projektem, nie gwarancją uzyskania tych poziomów.
   W pierwszej kolejności badać panel przy około 100% zmierzonego WT, następnie krzywe zależności od ilości.
   Nie odrzucać produktu na podstawie ESM bez eksperymentu. Wariant skrócony może zachowywać część funkcji;
   nie zakładać z góry jego biologicznego zera.
2. **RNA i readthrough:** oddzielny model z zachowanym kontekstem splicingu/NMD lub odpowiednie komórki endogenne.
   Sprawdzić alleloswoiste RNA, pełną długość białka i tożsamość reszty 737. Sam cDNA reporter nie testuje EJC-NMD.
   Kontrole reportera powinny oddzielać readthrough od efektów na aktywność/stabilność reportera.
   Sam wzrost sygnału lucyferazy nie wystarcza; potrzebny odczyt ortogonalny białka.
3. **Causal rescue:** pierwotny endpoint to błędy segregacji / zakończone podziały.
   Równolegle: liczba zakończonych podziałów, śmierć/apoptoza, czas mitozy, checkpoint i lokalizacja kinetochorowa.
   WT restoration jako dodatnia kontrola przyczynowa. Dla leków sprawdzić, czy efekt wymaga readthrough BUB1B,
   a nie tylko zmiany zapalenia/stresu lub selekcji komórek.
4. **Plan analizy:** jednostką replikacji jest niezależny eksperyment biologiczny; podziały/komórki to obserwacje zagnieżdżone.
   Pilot ma oszacować wyjściowe ryzyko i zmienność między replikacjami. 8 replikacji w szablonie pochodzi z kierunku
   przyjętego w NB10/F0 i nie dowodzi mocy dla nowego panelu, nowych wielokrotnych porównań lub readthrough.
   Przed wykonaniem zamrozić kontrasty, korektę wielokrotności i biologicznie uzasadniony efekt docelowy.
   Raportować różnicę bezwzględną, względną i 95% CI z zachowaniem struktury replikacji.
5. **Ekspozycja:** osobno zweryfikować ekspozycję wolną, wiązanie w pożywce i docelowej tkance.
   Nominalne stężenia z innych genów nie są dawkami dla BUB1B ani dawkami dla człowieka.
6. **Warunki zatrzymania:** brak pełnej długości białka; produkt pełnej długości bez poprawy funkcji;
   pozorna poprawa wyjaśniona zatrzymaniem podziałów/śmiercią; efekt tylko przy nieuzasadnionej ekspozycji.
   Nie zmieniać endpointu na ATP, przeżycie czy sygnaturę RNA po negatywnym wyniku segregacji.

Całość zachowuje warunkową interpretację genotypu z nierozstrzygniętą fazą.
NMD pozostaje predykcją do chwili pomiaru. Hamowanie NMD samo w sobie nie jest tutaj propozycją leczenia.
